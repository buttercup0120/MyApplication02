package com.example.myapplication02;


public class FinalActivity {
    String name;
    String address;
    int resild;

    public FinalActivity(String name, String address, int resild) {
        this.name = name;
        this.address = address;
        this.resild = resild;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name=name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address=address;
    }

    public int getResild() {
        return resild;
    }

    @Override
    public String toString() {
        return "SingerItem{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                '}';

    }
}