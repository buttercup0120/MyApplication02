package com.example.myapplication02;

import android.content.Context;
import android.view.LayoutInflater;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class FinalActivityView extends LinearLayout {
    TextView textView, textView2;
    ImageView imageView;

    public FinalActivityView(Context context) {
        super(context);
        init(context);
    }

    public FinalActivityView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    private void init(Context context) {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.activity_final,this, true);

        textView = findViewById(R.id.textView);
        textView2= findViewById(R.id.textView2);
        imageView= findViewById(R.id.imageView);
    }

    public void setName(String name) {
        textView.setText(name);
    }
    public void setAddress(String address) {
        textView2.setText(address);
    }

    public void setImage(int resild) {
        imageView.setImageResource(resild);
    }
}
