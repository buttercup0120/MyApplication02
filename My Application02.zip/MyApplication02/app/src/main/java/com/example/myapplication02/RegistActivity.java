package com.example.myapplication02;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplication02.R;

public class RegistActivity extends AppCompatActivity {

    private EditText etEamil;
    private EditText etPassword;
    private EditText etPasswordCheck;
    private EditText etName;
    private EditText etAge;
    private EditText etMaj;
    private EditText etHak;
    private Button btnJoin;
    private Button btnDoubleCheck;

    @Override
    protected void onCreate(Bundle savedlnstanceState) {
        super.onCreate(savedlnstanceState);
        setContentView(R.layout.activity_regist);

        etEamil = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);
        etPasswordCheck = (EditText) findViewById(R.id.etPasswordCheck);
        etName = (EditText) findViewById(R.id.etName);
        etAge = (EditText) findViewById(R.id.etAge);
        etMaj = (EditText) findViewById(R.id.etMaj);
        etHak = (EditText) findViewById(R.id.etHak);
        btnJoin = (Button) findViewById(R.id.btnJoin);
        btnDoubleCheck = (Button) findViewById(R.id.btnDoubleCheck);

        etPasswordCheck.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = etPassword.getText().toString();
                String check = etPasswordCheck.getText().toString();

                if(password.equals(check)) {
                    etPassword.setBackgroundColor(Color.GREEN);
                    etPasswordCheck.setBackgroundColor(Color.GREEN);
                } else {
                    etPassword.setBackgroundColor(Color.RED);
                    etPasswordCheck.setBackgroundColor(Color.RED);
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btnJoin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(etEamil.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "Email을 입력하세요!", Toast.LENGTH_SHORT).show();
                    etEamil.requestFocus();
                    return;

                }

                if(etPassword.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "비밀번호를 입력하세요!", Toast.LENGTH_SHORT).show();
                    etPassword.requestFocus();
                    return;
                }

                if(etPasswordCheck.getText().toString().equals(etPasswordCheck.getText().toString())) {
                    Toast.makeText(RegistActivity.this, "비밀번호 확인을 입력하세요!", Toast.LENGTH_SHORT).show();
                    etPasswordCheck.requestFocus();
                    return;
                }

                Intent result = new Intent();
                result.putExtra("email", etEamil.getText().toString());

                setResult(RESULT_OK, result);
                finish();

                if(etName.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "Name을 입력하세요!", Toast.LENGTH_SHORT).show();
                    etName.requestFocus();
                    return;

                }

                if(etAge.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "Age을 입력하세요!", Toast.LENGTH_SHORT).show();
                    etAge.requestFocus();
                    return;

                }

                if(etMaj.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "전공을 입력하세요!", Toast.LENGTH_SHORT).show();
                    etMaj.requestFocus();
                    return;

                }

                if(etHak.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "학번을 입력하세요!", Toast.LENGTH_SHORT).show();
                    etHak.requestFocus();
                    return;

                }
            }
        });

        btnDoubleCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}

